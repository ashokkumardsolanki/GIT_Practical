﻿using AutoMapper;
using GI_Practical_Core.Models;
using GI_Practical_Core.ViewModel;

namespace GI_Practical_Core.AMapper
{
    public class Automapper_Profile : Profile
    {
        public Automapper_Profile()
        {
            CreateMap<users_tab, users_dto>();
            CreateMap<users_dto, users_tab>();

            CreateMap<country_tab, country_dto>();
            CreateMap<country_dto, country_tab>();

            CreateMap<state_tab, state_dto>();
            CreateMap<state_dto, state_tab>();

            CreateMap<city_tab, city_dto>();
            CreateMap<city_dto, city_tab>();
        }
    }
}
