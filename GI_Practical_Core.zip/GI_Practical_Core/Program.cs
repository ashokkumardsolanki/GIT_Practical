using GI_Practical_Core.AMapper;
using GI_Practical_Core.Data;
using GI_Practical_Core.Interfaces;
using GI_Practical_Core.Repositoty;
using GI_Practical_Core.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;


var builder = WebApplication.CreateBuilder(args);


// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddAutoMapper(typeof(Automapper_Profile));

string conn= builder.Configuration.GetConnectionString("GI_DB");

builder.Services.AddDbContext<GI_DBContext>(e => e.UseSqlServer(conn));
builder.Services.AddTransient<IUser, User_Repository>();
builder.Services.AddTransient<IAddress, Address_Repository>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
