﻿using GI_Practical_Core.ViewModel;

namespace GI_Practical_Core.Interfaces
{
    public interface IUser
    {
        users_dto AddUser(users_dto user);
        List<users_dto> GetUserList(datatable_dto obj);
    }
}
