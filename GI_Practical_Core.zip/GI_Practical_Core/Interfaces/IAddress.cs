﻿using GI_Practical_Core.ViewModel;

namespace GI_Practical_Core.Interfaces
{
    public interface IAddress
    {
        List<country_dto> GetCounty();
        List<state_dto> GetState(int countyid);
        List<city_dto> Getcity(int stateid);
    }
}
