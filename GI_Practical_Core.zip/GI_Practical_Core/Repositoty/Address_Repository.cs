﻿using AutoMapper;
using GI_Practical_Core.Data;
using GI_Practical_Core.Interfaces;
using GI_Practical_Core.ViewModel;
using System.Collections.Generic;

namespace GI_Practical_Core.Repositoty
{
    public class Address_Repository : IAddress
    {
        private readonly GI_DBContext gI_DBContext;
        private readonly IMapper _mapper;
        public Address_Repository(GI_DBContext _gI_DBContext, IMapper mapper)
        {
            this.gI_DBContext = _gI_DBContext;
            this._mapper = mapper;
        }

        public List<country_dto> GetCounty()
        {
            List<country_dto> lst = new List<country_dto>();
            try
            {
                var country= gI_DBContext.country_tab.Where(e=>e.isactive==1).ToList().OrderBy(e=>e.country);
                lst = _mapper.Map<List<country_dto>>(country);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lst;
        }

        public List<state_dto> GetState(int countyid)
               {
            List<state_dto> lst = new List<state_dto>();
            try
            {
                var states = gI_DBContext.state_tab.Where(e => e.isactive == 1 && e.countryid==countyid).ToList().OrderBy(e => e.state);
                lst = _mapper.Map<List<state_dto>>(states);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lst;
        }
        public List<city_dto> Getcity(int stateid)
        {
            List<city_dto> lst = new List<city_dto>();
            try
            {
                var states = gI_DBContext.city_tab.Where(e => e.isactive == 1 && e.stateid == stateid).ToList().OrderBy(e => e.city);
                lst = _mapper.Map<List<city_dto>>(states);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lst;
        }

    }
}
