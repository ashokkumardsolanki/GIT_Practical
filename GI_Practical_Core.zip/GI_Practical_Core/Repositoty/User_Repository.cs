﻿using AutoMapper;
using GI_Practical_Core.Data;
using GI_Practical_Core.Interfaces;
using GI_Practical_Core.Models;
using GI_Practical_Core.ViewModel;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.Metrics;
using System.Text;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace GI_Practical_Core.Repositoty
{
    public class User_Repository : IUser
    {
        private readonly GI_DBContext dBContext;
        private readonly IMapper _mapper;

        public User_Repository(GI_DBContext _DBContext, IMapper mapper)
        {
            this.dBContext = _DBContext;
            this._mapper = mapper;
        }

        public users_dto AddUser(users_dto user)
        {
            users_dto retobj = new users_dto();
            try
            {
                users_tab addUser = new users_tab();
                addUser = _mapper.Map<users_tab>(user);
                addUser.isactive = 1;
                addUser.createdby = 1;
                addUser.createdon = DateTime.Now;

                dBContext.users_tab.Add(addUser);
                int re = dBContext.SaveChanges();
                if (re > 0)
                {
                    retobj = _mapper.Map<users_dto>(addUser);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return retobj;
        }

        public List<users_dto> GetUserList(datatable_dto obj)
        {
            List<users_dto> retLst = new List<users_dto>();
            try
            {
                int count= (from user in dBContext.users_tab
                            join coun in dBContext.country_tab on user.country equals coun.countryid
                            join sta in dBContext.state_tab on user.state equals sta.stateid
                            join cit in dBContext.city_tab on user.city equals cit.cityid
                            select new users_dto
                            {
                                firstname = user.firstname,
                                lastname = user.lastname,
                                email = user.email,
                                mobileno = user.mobileno,
                                gender = user.gender,
                                countryname = coun.country,
                                statename = sta.state,
                                cityname = cit.city,
                                pincode = user.pincode,
                                status = user.isactive == 1 ? "Active" : "Deactive"
                            }).Count();

               
                retLst = (from user in dBContext.users_tab
                          join coun in dBContext.country_tab on user.country equals coun.countryid
                          join sta in dBContext.state_tab on user.state equals sta.stateid
                          join cit in dBContext.city_tab on user.city equals cit.cityid
                          select new users_dto
                          {
                              Id = user.Id,
                              firstname = user.firstname,
                              lastname = user.lastname,
                              email = user.email,
                              mobileno = user.mobileno,
                              gender = user.gender,
                              country = user.country,
                              countryname = coun.country,
                              state = user.state,
                              statename = sta.state,
                              city = user.city,
                              cityname = cit.city,
                              pincode = user.pincode,
                              status = user.isactive == 1 ? "Active" : "Deactive"
                          }).Skip(obj.skip).Take(obj.pageSize).ToList();

                retLst[0].totalCount = count;
            }
            catch (Exception e)
            {
                throw;
            }
            return retLst;
        }
    }
}
