﻿using System.ComponentModel.DataAnnotations;

namespace GI_Practical_Core.Models
{
    public class users_tab
    {
        [Key]
        public int Id { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string email { get; set; }
        public string mobileno { get; set; }
        public string gender { get; set; }
        public int country { get; set; }
        public int state { get; set; }
        public int city { get; set; }
        public string pincode { get; set; }
        public string profile_pic { get; set; }
        public int isactive { get; set; }
        public int createdby { get; set; }
        public DateTime? createdon { get; set; }
        public int updatedby { get; set; }
        public DateTime? updatedon { get; set; }
    }
}
