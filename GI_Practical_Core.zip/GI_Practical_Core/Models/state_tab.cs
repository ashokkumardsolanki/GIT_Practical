﻿using System.ComponentModel.DataAnnotations;

namespace GI_Practical_Core.Models
{
    public class state_tab
    {
        [Key]
        public int stateid { get; set; }
        public int countryid { get; set; }
        public string state { get; set; }
        public int isactive { get; set; }
    }
}
