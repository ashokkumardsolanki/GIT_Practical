﻿using System.ComponentModel.DataAnnotations;

namespace GI_Practical_Core.Models
{
    public class city_tab
    {
        [Key]
        public int cityid { get; set; }
        public int stateid { get; set; }
        public string city { get; set; }
        public int isactive { get; set; }
    }
}
