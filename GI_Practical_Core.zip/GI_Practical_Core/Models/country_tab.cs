﻿using System.ComponentModel.DataAnnotations;

namespace GI_Practical_Core.Models
{
    public class country_tab
    {
        [Key]
        public int countryid { get; set; }
        public string country { get; set; }
        public int isactive { get; set; }
    }
}
