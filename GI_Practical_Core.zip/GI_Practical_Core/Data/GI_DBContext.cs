﻿using GI_Practical_Core.Models;
using Microsoft.EntityFrameworkCore;

namespace GI_Practical_Core.Data
{
    public class GI_DBContext : DbContext
    {
        public GI_DBContext(DbContextOptions<GI_DBContext> options) : base(options) { }

        public DbSet<users_tab> users_tab { get; set; }
        public DbSet<country_tab> country_tab { get; set; }
        public DbSet<state_tab> state_tab { get; set; }
        public DbSet<city_tab> city_tab { get; set; }

    }
}
