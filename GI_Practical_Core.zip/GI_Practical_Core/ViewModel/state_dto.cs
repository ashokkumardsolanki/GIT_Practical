﻿namespace GI_Practical_Core.ViewModel
{
    public class state_dto
    {
        public int stateid { get; set; }
        public int countryid { get; set; }
        public string state { get; set; }
        public int isactive { get; set; }
    }
}
