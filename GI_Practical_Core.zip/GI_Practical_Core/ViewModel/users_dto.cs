﻿using System.ComponentModel.DataAnnotations;

namespace GI_Practical_Core.ViewModel
{
    public class users_dto
    {
        public int Id { get; set; }

        [Required(ErrorMessage ="FirstName must be required")]
        public string firstname { get; set; }

        [Required(ErrorMessage = "LastName must be required")]
        public string lastname { get; set; }

        [Required(ErrorMessage = "Email must be required")]
        [DataType(DataType.EmailAddress)]
        [RegularExpression(RegexPatterns.Email, ErrorMessage = "Email Id is not Valid.")]
        [EmailAddress]
        public string email { get; set; }

        [Required(ErrorMessage = "Mobile must be required")]
        [Display(Name = "Mobile Number:")]
        [RegularExpression("^([0-9]{10})$", ErrorMessage = "Invalid Mobile Number.")]
        public string mobileno { get; set; }

        public string gender { get; set; }=string.Empty;

        [Required(ErrorMessage = "Country must be required")]
        public int country { get; set; }

        [Required(ErrorMessage = "State must be required")]
        public int state { get; set; }

        [Required(ErrorMessage = "City must be required")]
        public int city { get; set; }
        public string pincode { get; set; } = string.Empty;
        public string profile_pic { get; set; } = string.Empty;
        public int? isactive { get; set; }
        public int? createdby { get; set; }
        public DateTime? createdon { get; set; }
        public int? updatedby { get; set; }
        public DateTime? updatedon { get; set; }


        // for grid purpose
        public string countryname { get; set; }
        public string statename { get; set; }
        public string cityname { get; set; }

        public string status { get; set; }
        public int? totalCount { get; set; }
    }

    public static class RegexPatterns
    {
        public const string Email = @"^[\w-_]+(\.[\w!#$%'*+\/=?\^`{|}]+)*@((([\-\w]+\.)+[a-zA-Z]{2,20})|(([0-9]{1,3}\.){3}[0-9]{1,3}))$";
    }
}
