﻿namespace GI_Practical_Core.ViewModel
{
    public class country_dto
    {
        public int countryid { get; set; }
        public string country { get; set; }
        public int isactive { get; set; }
    }
}
