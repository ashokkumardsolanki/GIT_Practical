﻿namespace GI_Practical_Core.ViewModel
{
    public class city_dto
    {
        public int cityid { get; set; }
        public int stateid { get; set; }
        public string city { get; set; }
        public int isactive { get; set; }
    }
}
